module.exports = {
  bail: true,
  verbose: false,
  testEnvironment: 'node'
}
